<div id="sidebar">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>		

		<div class="box clearfloat">
			<div class="boxinside clearfloat">
				<h4>Bookmarks</h4>
					<p><!-- AddThis Button BEGIN -->
						<div class="addthis_toolbox addthis_default_style addthis_32x32_style">
						    <a class="addthis_button_facebook"></a>
						    <a class="addthis_button_twitter"></a>
						    <a class="addthis_button_email"></a>
						    <a class="addthis_button_favorites"></a>
						    <a class="addthis_button_stumbleupon"></a>
						    <a class="addthis_button_myspace"></a>
						    <a class="addthis_button_compact"></a>
   						</div>
					<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=xa-4d8b095f491dae02"></script>
					<!-- AddThis Button END --></p>
			</div>
		</div>

		<div class="box clearfloat">
			<div class="boxinside clearfloat">
				<h4>Video</h4>
					<iframe src="http://player.vimeo.com/video/6006857?byline=0&amp;portrait=0" width="260" height="143" frameborder="0"></iframe>
			</div>
		</div>

		<div class="box clearfloat">
			<div class="boxinside clearfloat">
				<h4>Advertisements</h4>
					<div id="ads">				
						<ul>
							<li class="wide"><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/banners/tf_wide.gif" alt="" /></a></li>
							<li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/banners/tf.png" alt="" /></a></li>
							<li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/banners/ad.png" alt="" /></a></li>
							<li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/banners/cc.png" alt="" /></a></li>
							<li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/banners/gr.png" alt="" /></a></li>
						</ul>
					</div>
			</div>
		</div>

		<div class="box clearfloat">
			<div class="boxinside clearfloat">
				<h4>Latest Posts</h4>
					<?php
					$the_query = new WP_Query('showposts=5&orderby=post_date&order=desc');
					while ($the_query->have_posts()) : $the_query->the_post(); ?>
						<div class="latest-post">
							<?php the_post_thumbnail(array(30,30), array ('class' => 'alignleft')); ?>
							 <a title="<?php the_title(); ?>" href="<?php the_permalink() ?>" rel="bookmark"><?php the_title(); ?></a>
							 <div class="clear"></div>
						</div>				
					<?php endwhile; ?>
					<?php wp_reset_query(); ?>
			</div>
		</div>

	<?php endif; ?>	
</div> <!-- end div #sidebar -->
