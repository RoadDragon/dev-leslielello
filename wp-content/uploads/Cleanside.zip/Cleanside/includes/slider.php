<!-- BEGIN FEATURED AREA -->
<div id="featured-area">
<div id="featured-area-inner" class="clearfix">

	<!-- BEGIN SLIDER -->
	<?php if(!is_paged()) { ?>
	
	<div id="sliderbox_inner" class="inner clearfix">
	
	<?php query_posts('category_name=' . get_option('eted_feat_cat') . '&showposts=' . get_option('eted_feat_num')); ?>
	
	<div class="anythingSlider">
		<div class="wrapper">
			<ul>

				<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

					<li>

						<div class="entrysliderimg">
							<?php // This will show only the image. Alter the width and height (in both places) to your needs. ?>
							<div class="postthumb"><a href="<?php the_permalink() ?>"><?php the_post_thumbnail('slider-image'); ?></a></div>
						</div>
						
						<div class="entryslider">
							<h2><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
						</div>
										
					</li>
		
						<?php endwhile; else: ?>
						<?php endif; ?>
				</ul> <!-- end post -->

		</div><!-- end div .anythingSlider.wrapper -->
		
	</div><!-- end div .anythingSlider -->
	
	<?php wp_reset_query(); ?>
	
	</div> <!-- end div sliderbox_inner -->
	
	<?php } ?>
	<!-- END SLIDER -->

</div> <!-- end div #featured-area-inner -->
</div> <!-- end div #featured-area -->
<!-- END FEATURED AREA -->



	
