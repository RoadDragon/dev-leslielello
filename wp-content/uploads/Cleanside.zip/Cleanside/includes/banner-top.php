<div id="banner-top">
	<p><?php echo stripslashes(get_option('eted_banner_top')); ?></p>
</div> <!-- end #banner-top -->

