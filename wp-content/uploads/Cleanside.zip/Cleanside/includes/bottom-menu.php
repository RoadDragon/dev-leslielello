<!-- BEGIN BOTTOM-MENU -->
<div id="bottom-menu">
<div id="bottom-menu-inner" class="clearfix">
	
<div id="bottom-menu-left">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Bottom Menu Left') ) : ?>
		<h4>Widgetised area</h4>
			<p>This is a widgetised area. To fill it with 'stuff', use the Bottom Menu Left widget.</p>
	<?php endif; ?>
</div> <!-- end div #bottom-menu-left -->

<div id="bottom-menu-center">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Bottom Menu Center') ) : ?>
		<h4>Widgetised area</h4>
			<p>This is a widgetised area. To fill it with 'stuff', use the Bottom Menu Center widget.</p>
	<?php endif; ?>
</div> <!-- end div #bottom-menu-center -->

<div id="bottom-menu-right">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Bottom Menu Right') ) : ?>
		<h4>Widgetised area</h4>
			<p>This is a widgetised area. To fill it with 'stuff', use the Bottom Menu Right widget.</p>
	<?php endif; ?>
</div> <!-- end div #bottom-menu-right -->

</div> <!-- end div #bottom-menu-inner -->
</div> <!-- end div #bottom-menu -->
<!-- END BOTTOM-MENU -->
