<?php
/*

	Section: Credit
	Author: CyberChimps
	Description: It is completely optional, but if you like the theme we would appreciate it if you keep the credit link at the bottom.
	Version: 0.1
	
*/
?>

<div class="credit">
<a href="http://cyberchimps.com/" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/images/achimps.png" /></a>
</div>