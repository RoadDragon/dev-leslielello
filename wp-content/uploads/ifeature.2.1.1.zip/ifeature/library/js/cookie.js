$(function() {
		$("#tabs").tabs({
			cookie: {
				expires: 30
			}
		});
	});

    

