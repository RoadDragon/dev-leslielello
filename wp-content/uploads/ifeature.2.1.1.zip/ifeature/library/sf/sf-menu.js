var $ = jQuery.noConflict();
    $(document).ready(function(){
        jQuery('ul.sf-menu').superfish();
    });
