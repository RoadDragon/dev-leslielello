iFeature is a free WordPress theme designed by CyberChimps.com in California.

Theme Homepage -  http://cyberchimps.com/ifeature/

Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html
---------------------------------------------------------------------------

For updated documentation, walkthroughs, and support please visit http://cyberchimps.com/docs/

To upgrade to iFeature Pro please visit: http://cyberchimps.com/ifeaturepro/

For the support forum please visit: http://cyberchimps.com/forum/

For all other questions please visit: http://cyberchimps.com/support/